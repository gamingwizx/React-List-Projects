import logo from "./logo.svg";
import "./App.css";
import Home from "./Pages/Home/Home.js";
import Product from "./Pages/Product/Product.js";
import Login from "./Pages/Login/Login.js";
import Pricing from "./Pages/Pricing/Pricing.js";
import Header from "./Pages/Header.js";
import AppLayout from "./Pages/Map/AppLayout.jsx";
import City from "./Pages/Cities/City.jsx";
import { Route, Routes, BrowserRouter, Navigate } from "react-router-dom";
import { CitiesProvider } from "./Context/CitiesContext.jsx";
function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="" element={<Home />} />
        <Route path="product" element={<Product />} />
        <Route path="pricing" element={<Pricing />} />
        <Route path="login" element={<Login />} />
        <Route path="app" element={<AppLayout />}>
          <Route index element={<Navigate replace to="cities" />} />
          <Route path="cities" element={<City />}></Route>
        </Route>
      </Routes>
    </div>
  );
}

export default App;
