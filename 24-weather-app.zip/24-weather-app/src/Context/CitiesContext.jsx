import { useState, useEffect, useReducer, createContext, useContext } from "react";

const initialState = {
  cities: [],
};
const CitiesContext = createContext();

const reducer = (state, action) => {
  switch (action.type) {
    case "cities/load":
      return { ...state, cities: action.payload };
  }
};

function CitiesProvider({children}) {
  const [{ cities }, dispatch] = useReducer(reducer, initialState);
  useEffect(() => {
    async function fetchCities() {
      fetch("http://localhost:8000/cities")
        .then((result) => {
          if (!result.ok)
            throw new Error("Something went wrong when fetching API");
          return result.json();
        })
        .then((result) => {
          dispatch({ type: "cities/load", payload: result });
        });
    }
    fetchCities();
  }, []);

  return (<CitiesContext.Provider value={{cities}}>{children}</CitiesContext.Provider>);
}

function useCities() {
  const context = useContext(CitiesContext);
  if (context === undefined) {
    throw new Error("CitiesContext is not defined");
  }
  return context;
};

export { CitiesProvider, useCities };
