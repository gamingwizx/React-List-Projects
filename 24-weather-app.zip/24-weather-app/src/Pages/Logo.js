export default function Logo() {
    return <div>
    <img className="icon" src="./icon.png" />
        <p>WorldWise</p>
    </div>
}