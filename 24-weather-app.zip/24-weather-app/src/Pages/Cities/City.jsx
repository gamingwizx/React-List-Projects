import {useCities} from "../../Context/CitiesContext"
export default function City() {
    const {cities} = useCities()
    console.log(cities)
    return (
        <>
        <p>asd</p>
        {cities.map((city) => (
            <div className="cityItem">
                {city.emoji}{city.cityName}{city.date}
            </div>
        ))}
        </>
    )
}