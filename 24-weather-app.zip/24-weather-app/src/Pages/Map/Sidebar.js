import {NavLink, Outlet} from "react-router-dom"
import styles from "./Sidebar.module.css"
import Logo from "../Logo.js"
export default function Sidebar() {
    return (
      <div className={styles.sidebar}>
        <Logo />
        <div className={styles.mapNav}>
        <NavLink to="cities">Cities</NavLink>
        <NavLink to="countries">Countries</NavLink>
        </div>
        <Outlet />
      </div>
    )
}